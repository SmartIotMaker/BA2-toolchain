
Date of compilation: 08-April-2012
Xiaofan Chen

To use libftdi 0.20 version under Windows, you need to use libusb-win32 driver.

There are two methods to install libusb-win32 driver for use with libftdi-0.20.
1) To install device driver, use Driver\inf-wizard to replace the 
existing FTDI driver to libusb-win32 device driver.

2) To install filter driver, use Driver\libusb-win32-devel-filter-1.2.6.0 
to install the filter driver on top of FTDI driver. This will ensure
you can still run FTDI d2xx based application.

The two driver installers works under 32bit and 64bit Windows.

To test if the driver installation is working, run bin\testlibusb-win.exe 
to see if the device is recognized and the descriptors are dumped.

The copyright information about libftdi and libusb-win32 are inside
the copyright directory.

The html_doc directory is the doxygen generated compiled HTML document for libftdi.
libusb-win32 wiki is at the following URL.
http://sourceforge.net/apps/trac/libusb-win32/wiki

The bin directory contains the dlls and example program for libftdi 0.20 and
libusb-win32 1.2.6.0. The source codes for the examples programs are inside
the source sub-directory.

libusb-win32 source codes can be downloaded at its Sourceforge site.
http://sourceforge.net/projects/libusb-win32/files/libusb-win32-releases/1.2.6.0/

libftdi-0.20 source codes can be downloaded here.
http://www.intra2net.com/en/developer/libftdi/download.php
http://www.intra2net.com/en/developer/libftdi/download/libftdi-0.20.tar.gz

Tools used to build this package. This is the first time I am using non-MinGW.org distro of MinGW (due to the desire to build the Boost wrapper) and hopefully this does not create big problems.
CMake 2.8.7: http://www.cmake.org/
Doxygen 1.8.0: http://www.stack.nl/~dimitri/doxygen/
MinGW with Boost: http://nuwen.net/mingw.html version 9.0, containing GCC 4.7.0 and Boost 1.49.0.
swig for Windows 2.04: http://www.swig.org/download.html
Python 2.7.2: http://www.python.org


